/* =====================================================
   SMART MENU - BACKEND INTEGRATION
   ===================================================== */

// Backend API URL
const API_URL = "http://localhost:5014/api/orders";

// Cart from localStorage
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Update cart badge
function updateCartBadge() {
    const badge = document.getElementById("cart-badge");
    if (badge) {
        const count = cart.reduce((sum, item) => sum + item.qty, 0);
        badge.textContent = count;
    }
}

// Add to cart (Event Delegation)
document.addEventListener("click", (e) => {
    if (e.target.closest(".add-to-cart")) {
        const btn = e.target.closest(".add-to-cart");
        
        const id = btn.dataset.id;
        const name = btn.dataset.name;
        const price = parseFloat(btn.dataset.price);

        // Check if item exists
        const existingItem = cart.find(item => item.id === id);
        
        if (existingItem) {
            existingItem.qty++;
        } else {
            cart.push({ id, name, price, qty: 1 });
        }

        // Save and update
        localStorage.setItem("cart", JSON.stringify(cart));
        updateCartBadge();

        // Show feedback
        btn.innerHTML = '<i class="fas fa-check"></i> تمت الإضافة';
        setTimeout(() => {
            btn.innerHTML = '<i class="fas fa-plus"></i>';
        }, 1000);
    }
});

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
    updateCartBadge();
});
