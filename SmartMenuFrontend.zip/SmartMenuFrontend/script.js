/* =====================================================
   SMART MENU - MAIN JAVASCRIPT FILE
   ===================================================== */


/* =====================================================
   TOAST NOTIFICATIONS SYSTEM
   ===================================================== */


function showToast(message, type = 'success', title = null, duration = 3000) {
    const container = document.getElementById('toast-container');
    
    // Auto titles
    if (!title) {
        const titles = {
            'success': 'تم بنجاح!',
            'error': 'خطأ!',
            'info': 'معلومة',
            'warning': 'تحذير!'
        };
        title = titles[type] || 'إشعار';
    }
    
    // Icons
    const icons = {
        'success': 'fa-check-circle',
        'error': 'fa-times-circle',
        'info': 'fa-info-circle',
        'warning': 'fa-exclamation-triangle'
    };
    
    const icon = icons[type] || 'fa-bell';
    
    // Create toast
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <div class="toast-icon">
            <i class="fas ${icon}"></i>
        </div>
        <div class="toast-content">
            <div class="toast-title">${title}</div>
            <div class="toast-message">${message}</div>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    container.appendChild(toast);
    
    // Auto remove
    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
    }, duration);
}


/* =====================================================
   LOADING OVERLAY SYSTEM
   ===================================================== */


function showLoading() {
    const overlay = document.getElementById('loading-overlay');
    overlay.classList.add('active');
}


function hideLoading() {
    const overlay = document.getElementById('loading-overlay');
    overlay.classList.remove('active');
}


/* =====================================================
   FORM VALIDATION SYSTEM
   ===================================================== */


// Validation Rules
const validationRules = {
    name: {
        minLength: 3,
        maxLength: 50,
        pattern: /^[\u0621-\u064A\s]+$/,  // Arabic letters only
        messages: {
            required: 'الاسم مطلوب',
            minLength: 'الاسم يجب أن يكون 3 أحرف على الأقل',
            maxLength: 'الاسم يجب ألا يزيد عن 50 حرف',
            pattern: 'الاسم يجب أن يحتوي على حروف عربية فقط'
        }
    },
    phone: {
        length: 11,
        pattern: /^01[0-2,5]{1}[0-9]{8}$/,  // Egyptian phone format
        messages: {
            required: 'رقم الموبايل مطلوب',
            length: 'رقم الموبايل يجب أن يكون 11 رقم',
            pattern: 'رقم الموبايل يجب أن يبدأ بـ 010 أو 011 أو 012 أو 015'
        }
    },
    address: {
        minLength: 10,
        maxLength: 200,
        messages: {
            required: 'العنوان مطلوب',
            minLength: 'العنوان يجب أن يكون 10 أحرف على الأقل',
            maxLength: 'العنوان يجب ألا يزيد عن 200 حرف'
        }
    }
};


// Validate Name
function validateName(value) {
    const rules = validationRules.name;
    
    if (!value || value.trim() === '') {
        return { valid: false, message: rules.messages.required };
    }
    
    if (value.length < rules.minLength) {
        return { valid: false, message: rules.messages.minLength };
    }
    
    if (value.length > rules.maxLength) {
        return { valid: false, message: rules.messages.maxLength };
    }
    
    if (!rules.pattern.test(value)) {
        return { valid: false, message: rules.messages.pattern };
    }
    
    return { valid: true };
}


// Validate Phone
function validatePhone(value) {
    const rules = validationRules.phone;
    
    if (!value || value.trim() === '') {
        return { valid: false, message: rules.messages.required };
    }
    
    if (value.length !== rules.length) {
        return { valid: false, message: rules.messages.length };
    }
    
    if (!rules.pattern.test(value)) {
        return { valid: false, message: rules.messages.pattern };
    }
    
    return { valid: true };
}


// Validate Address
function validateAddress(value) {
    const rules = validationRules.address;
    
    if (!value || value.trim() === '') {
        return { valid: false, message: rules.messages.required };
    }
    
    if (value.length < rules.minLength) {
        return { valid: false, message: rules.messages.minLength };
    }
    
    if (value.length > rules.maxLength) {
        return { valid: false, message: rules.messages.maxLength };
    }
    
    return { valid: true };
}


// Show Field Error
function showFieldError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const errorDiv = document.getElementById(`${fieldId.replace('customer-', '')}-error`);
    const successDiv = document.getElementById(`${fieldId.replace('customer-', '')}-success`);
    
    field.classList.remove('is-valid');
    field.classList.add('is-invalid');
    
    errorDiv.querySelector('span').textContent = message;
    errorDiv.classList.add('show');
    
    if (successDiv) {
        successDiv.classList.remove('show');
    }
}


// Show Field Success
function showFieldSuccess(fieldId) {
    const field = document.getElementById(fieldId);
    const errorDiv = document.getElementById(`${fieldId.replace('customer-', '')}-error`);
    const successDiv = document.getElementById(`${fieldId.replace('customer-', '')}-success`);
    
    field.classList.remove('is-invalid');
    field.classList.add('is-valid');
    
    errorDiv.classList.remove('show');
    
    if (successDiv) {
        successDiv.classList.add('show');
    }
}


// Clear Field Validation
function clearFieldValidation(fieldId) {
    const field = document.getElementById(fieldId);
    const errorDiv = document.getElementById(`${fieldId.replace('customer-', '')}-error`);
    const successDiv = document.getElementById(`${fieldId.replace('customer-', '')}-success`);
    
    field.classList.remove('is-valid', 'is-invalid');
    errorDiv.classList.remove('show');
    
    if (successDiv) {
        successDiv.classList.remove('show');
    }
}


// Setup Real-time Validation
function setupFormValidation() {
    const nameField = document.getElementById('customer-name');
    const phoneField = document.getElementById('customer-phone');
    const addressField = document.getElementById('customer-address');
    
    // Name validation
    nameField.addEventListener('input', function() {
        const value = this.value;
        const result = validateName(value);
        
        if (value === '') {
            clearFieldValidation('customer-name');
        } else if (result.valid) {
            showFieldSuccess('customer-name');
        } else {
            showFieldError('customer-name', result.message);
        }
    });
    
    // Phone validation + counter
    phoneField.addEventListener('input', function() {
        const value = this.value.replace(/\D/g, ''); // Numbers only
        this.value = value;
        
        const counter = document.getElementById('phone-counter');
        counter.textContent = `${value.length} / 11`;
        
        if (value.length >= 11) {
            counter.classList.remove('warning');
            counter.classList.add('error');
        } else if (value.length >= 8) {
            counter.classList.add('warning');
            counter.classList.remove('error');
        } else {
            counter.classList.remove('warning', 'error');
        }
        
        const result = validatePhone(value);
        
        if (value === '') {
            clearFieldValidation('customer-phone');
        } else if (result.valid) {
            showFieldSuccess('customer-phone');
        } else {
            showFieldError('customer-phone', result.message);
        }
    });
    
    // Address validation + counter
    addressField.addEventListener('input', function() {
        const value = this.value;
        const counter = document.getElementById('address-counter');
        counter.textContent = `${value.length} / 10 حد أدنى`;
        
        if (value.length >= 10) {
            counter.classList.remove('error');
        } else if (value.length >= 5) {
            counter.classList.add('warning');
        } else {
            counter.classList.remove('warning');
        }
        
        const result = validateAddress(value);
        
        if (value === '') {
            clearFieldValidation('customer-address');
        } else if (result.valid) {
            showFieldSuccess('customer-address');
        } else {
            showFieldError('customer-address', result.message);
        }
    });
}


// Initialize validation when modal opens
document.getElementById('checkoutModal').addEventListener('shown.bs.modal', function() {
    setupFormValidation();
});


/* =====================================================
   SCROLL TO TOP BUTTON
   ===================================================== */


// Show/Hide button on scroll
window.addEventListener('scroll', function() {
    const scrollBtn = document.getElementById('scroll-top-btn');
    if (window.pageYOffset > 300) {
        scrollBtn.classList.add('show');
    } else {
        scrollBtn.classList.remove('show');
    }
});


// Scroll to top function
function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}


/* =====================================================
   MENU DATA & CART
   ===================================================== */


// Menu Items Data
const menuItems = [
    {
        id: 1,
        name: "برجر كلاسيك",
        description: "برجر لحم مع الخضار والصوص الخاص",
        price: 35.00,
        image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400"
    },
    {
        id: 2,
        name: "بيتزا مارجريتا",
        description: "بيتزا إيطالية بالجبن والطماطم",
        price: 50.00,
        image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=400"
    },
    {
        id: 3,
        name: "دجاج مقلي",
        description: "قطع دجاج مقرمشة مع الصوص",
        price: 30.00,
        image: "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=400"
    },
    {
        id: 4,
        name: "باستا كاربونارا",
        description: "باستا إيطالية بالكريمة والجبن",
        price: 40.00,
        image: "https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400"
    },
    {
        id: 5,
        name: "سلطة سيزر",
        description: "سلطة طازجة مع صوص سيزر",
        price: 25.00,
        image: "https://images.unsplash.com/photo-1546793665-c74683f339c1?w=400"
    },
    {
        id: 6,
        name: "عصير برتقال طازج",
        description: "عصير برتقال طبيعي 100%",
        price: 15.00,
        image: "https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=400"
    }
];


// Cart Array
let cart = [];


// Load Menu Items
function loadMenu() {
    const container = document.getElementById('menu-items');
    container.innerHTML = menuItems.map(item => `
        <div class="col-md-4">
            <div class="menu-card">
                <img src="${item.image}" alt="${item.name}">
                <div class="menu-card-body">
                    <h5 class="menu-card-title">${item.name}</h5>
                    <p class="menu-card-description">${item.description}</p>
                    <div class="menu-card-footer">
                        <span class="menu-card-price">${item.price.toFixed(2)} ريال</span>
                        <button class="btn btn-add-to-cart" onclick="addToCart(${JSON.stringify(item).replace(/"/g, '&quot;')})">
                            <i class="fas fa-plus"></i> إضافة
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}


// Add to Cart
function addToCart(item) {
    const existingItem = cart.find(cartItem => cartItem.id === item.id);
    
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ ...item, quantity: 1 });
    }
    
    updateCart();
    showToast(`تمت إضافة ${item.name} إلى السلة`, 'success');
}


// Update Cart Display
function updateCart() {
    const cartCount = document.getElementById('cart-count');
    const cartItems = document.getElementById('cart-items');
    const cartSummary = document.getElementById('cart-summary');
    const checkoutBtn = document.getElementById('checkout-btn');
    
    // Update count
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    
    if (cart.length === 0) {
        cartItems.innerHTML = '<p class="text-center text-muted">السلة فارغة</p>';
        cartSummary.style.display = 'none';
        checkoutBtn.style.display = 'none';
        return;
    }
    
    // Display cart items
    cartItems.innerHTML = cart.map((item, index) => `
        <div class="cart-item">
            <div class="cart-item-info">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">${item.price.toFixed(2)} ريال</div>
            </div>
            <div class="cart-item-quantity">
                <button class="quantity-btn" onclick="decreaseQuantity(${index})">
                    <i class="fas fa-minus"></i>
                </button>
                <span class="quantity-display">${item.quantity}</span>
                <button class="quantity-btn" onclick="increaseQuantity(${index})">
                    <i class="fas fa-plus"></i>
                </button>
            </div>
            <button class="cart-item-remove" onclick="removeFromCart(${index})">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `).join('');
    
    // Calculate totals
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.15;
    const total = subtotal + tax;
    
    document.getElementById('cart-subtotal').textContent = `${subtotal.toFixed(2)} ريال`;
    document.getElementById('cart-tax').textContent = `${tax.toFixed(2)} ريال`;
    document.getElementById('cart-total').textContent = `${total.toFixed(2)} ريال`;
    
    cartSummary.style.display = 'block';
    checkoutBtn.style.display = 'inline-block';
}


// Increase Quantity
function increaseQuantity(index) {
    cart[index].quantity++;
    updateCart();
}


// Decrease Quantity
function decreaseQuantity(index) {
    if (cart[index].quantity > 1) {
        cart[index].quantity--;
        updateCart();
    } else {
        removeFromCart(index);
    }
}


// Remove from Cart
function removeFromCart(index) {
    cart.splice(index, 1);
    updateCart();
    showToast('تم حذف المنتج من السلة', 'info', 'تم الحذف');
}


// Proceed to Checkout
function proceedToCheckout() {
    if (cart.length === 0) {
        showToast('السلة فارغة! أضف منتجات أولاً', 'warning', 'تنبيه');
        return;
    }
    
    // Calculate totals
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.15;
    const total = subtotal + tax;
    
    // Update checkout modal
    document.getElementById('checkout-subtotal').textContent = `${subtotal.toFixed(2)} ريال`;
    document.getElementById('checkout-tax').textContent = `${tax.toFixed(2)} ريال`;
    document.getElementById('checkout-total').textContent = `${total.toFixed(2)} ريال`;
    
    // Close cart modal and open checkout modal
    const cartModal = bootstrap.Modal.getInstance(document.getElementById('cartModal'));
    cartModal.hide();
    
    const checkoutModal = new bootstrap.Modal(document.getElementById('checkoutModal'));
    checkoutModal.show();
}


// Submit Order
async function submitOrder() {
    // التحقق من السلة
    if (cart.length === 0) {
        showToast('السلة فارغة! أضف منتجات أولاً', 'warning', 'تنبيه');
        return;
    }

    // جمع البيانات
    const customerName = document.getElementById('customer-name').value.trim();
    const customerPhone = document.getElementById('customer-phone').value.trim();
    const customerAddress = document.getElementById('customer-address').value.trim();

    // Validation
    const nameValidation = validateName(customerName);
    const phoneValidation = validatePhone(customerPhone);
    const addressValidation = validateAddress(customerAddress);

    let hasErrors = false;

    if (!nameValidation.valid) {
        showFieldError('customer-name', nameValidation.message);
        hasErrors = true;
    }

    if (!phoneValidation.valid) {
        showFieldError('customer-phone', phoneValidation.message);
        hasErrors = true;
    }

    if (!addressValidation.valid) {
        showFieldError('customer-address', addressValidation.message);
        hasErrors = true;
    }

    if (hasErrors) {
        showToast('يرجى تصحيح الأخطاء في النموذج', 'error', 'خطأ في البيانات');
        return;
    }

    // حساب الأسعار
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.15;
    const totalAmount = subtotal + tax;

    // تجهيز بيانات الطلب
    const orderData = {
        customerName,
        customerPhone,
        customerAddress,
        subtotal,
        tax,
        totalAmount,
        items: cart.map(item => ({
            itemName: item.name,
            price: item.price,
            quantity: item.quantity
        }))
    };

    console.log('Sending order:', orderData); // للمراجعة

    // إظهار Loading
    showLoading();

    try {
        // إرسال الطلب
        const response = await fetch('http://localhost:5014/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(orderData)
        });

        // إخفاء Loading
        hideLoading();

        console.log('Response status:', response.status); // للمراجعة

        if (response.ok) {
            const result = await response.json();
            console.log('Order created:', result); // للمراجعة
            
            // نجح الطلب
            showToast('تم إرسال طلبك بنجاح! سنتواصل معك قريباً 🎉', 'success', 'شكراً لك!', 4000);
            
            // مسح السلة والفورم
            cart = [];
            updateCart();
            document.getElementById('customer-name').value = '';
            document.getElementById('customer-phone').value = '';
            document.getElementById('customer-address').value = '';
            
            // Clear validation states
            clearFieldValidation('customer-name');
            clearFieldValidation('customer-phone');
            clearFieldValidation('customer-address');

            // إغلاق المودال
            const modal = bootstrap.Modal.getInstance(document.getElementById('checkoutModal'));
            if (modal) modal.hide();

        } else {
            // فشل الطلب - محاولة قراءة الخطأ
            try {
                const error = await response.json();
                console.error('Error response:', error); // للمراجعة
                showToast(error.title || error.message || 'تعذر إرسال الطلب. حاول مرة أخرى', 'error');
            } catch (e) {
                showToast('تعذر إرسال الطلب. حاول مرة أخرى', 'error');
            }
        }

    } catch (error) {
        // إخفاء Loading
        hideLoading();
        
        console.error('Network error:', error);
        showToast('حدث خطأ في الاتصال. تأكد من تشغيل الـ Backend', 'error', 'خطأ في الاتصال');
    }
}


// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    loadMenu();
    updateCart();
});
