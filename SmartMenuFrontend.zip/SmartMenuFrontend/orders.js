/* =====================================================
   ORDERS PAGE - ADMIN PANEL
   ===================================================== */

const API_URL = "http://localhost:5014/api/orders";

// Load orders on page load
document.addEventListener("DOMContentLoaded", () => {
    loadOrders();
});

// Load all orders
async function loadOrders() {
    const container = document.getElementById("orders-container");
    
    container.innerHTML = `
        <div class="loading">
            <i class="fas fa-spinner fa-spin"></i>
            <p>جاري تحميل الطلبات...</p>
        </div>
    `;

    try {
        const response = await fetch(API_URL);
        
        if (!response.ok) {
            throw new Error("فشل تحميل الطلبات");
        }

        const orders = await response.json();
        
        if (orders.length === 0) {
            container.innerHTML = `
                <div class="no-orders">
                    <i class="fas fa-inbox"></i>
                    <h3>لا توجد طلبات حتى الآن</h3>
                    <p class="text-muted">الطلبات ستظهر هنا عندما يطلب العملاء</p>
                </div>
            `;
            updateStatistics(orders);
            return;
        }

        // Render orders
        container.innerHTML = orders.map(order => renderOrder(order)).join('');
        
        // Update statistics
        updateStatistics(orders);

    } catch (error) {
        console.error("Error:", error);
        container.innerHTML = `
            <div class="alert alert-danger text-center">
                <i class="fas fa-exclamation-triangle"></i>
                <h4>حدث خطأ!</h4>
                <p>تعذر تحميل الطلبات. تأكد من أن الـ Backend شغال.</p>
                <button class="btn btn-danger" onclick="loadOrders()">إعادة المحاولة</button>
            </div>
        `;
    }
}

// Render single order
function renderOrder(order) {
    const orderDate = new Date(order.orderDate).toLocaleString('ar-EG');
    const isToday = isOrderToday(order.orderDate);
    
    return `
        <div class="order-card">
            <div class="order-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="order-id">#${order.orderId}</span>
                        ${isToday ? '<span class="badge-new ms-2">جديد</span>' : ''}
                    </div>
                    <div class="text-muted">
                        <i class="fas fa-clock"></i> ${orderDate}
                    </div>
                </div>
            </div>

            <div class="customer-info">
                <div class="row">
                    <div class="col-md-4">
                        <i class="fas fa-user text-primary"></i>
                        <strong>العميل:</strong> ${order.customerName}
                    </div>
                    <div class="col-md-4">
                        <i class="fas fa-phone text-success"></i>
                        <strong>الموبايل:</strong> ${order.customerPhone}
                    </div>
                    <div class="col-md-4">
                        <i class="fas fa-map-marker-alt text-danger"></i>
                        <strong>العنوان:</strong> ${order.customerAddress}
                    </div>
                </div>
            </div>

            <div class="order-items">
                <h6 class="mb-3"><i class="fas fa-shopping-bag"></i> المنتجات:</h6>
                ${order.items.map(item => `
                    <div class="item-row">
                        <div class="d-flex justify-content-between">
                            <div>
                                <strong>${item.itemName}</strong>
                                <span class="text-muted">× ${item.quantity}</span>
                            </div>
                            <div>
                                ${(item.price * item.quantity).toFixed(2)} ريال
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>

            <div class="total-section">
                <div class="d-flex justify-content-between mb-2">
                    <span>المجموع:</span>
                    <strong>${order.subtotal.toFixed(2)} ريال</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>الضريبة (15%):</span>
                    <strong>${order.tax.toFixed(2)} ريال</strong>
                </div>
                <hr>
                <div class="d-flex justify-content-between">
                    <h5>الإجمالي:</h5>
                    <h5 class="text-success">${order.totalAmount.toFixed(2)} ريال</h5>
                </div>
            </div>
        </div>
    `;
}

// Update statistics
function updateStatistics(orders) {
    // Total orders
    document.getElementById("total-orders").textContent = orders.length;
    
    // Total sales
    const totalSales = orders.reduce((sum, order) => sum + order.totalAmount, 0);
    document.getElementById("total-sales").textContent = totalSales.toFixed(2);
    
    // Today's orders
    const todayOrders = orders.filter(order => isOrderToday(order.orderDate));
    document.getElementById("today-orders").textContent = todayOrders.length;
}

// Check if order is today
function isOrderToday(orderDate) {
    const today = new Date();
    const order = new Date(orderDate);
    
    return today.toDateString() === order.toDateString();
}
